import requests
import json
import time
import re
import os
import zipfile
from datetime import datetime


# 基础配置
BASE_URL = "http://114.214.255.82:8396"
SCRIPT_ID = "54d69e14-4f98-4df4-9581-878b025f600a"
EXECUTE_ENDPOINT = f"{BASE_URL}/api/scripts/{SCRIPT_ID}/execute"
RESULT_ENDPOINT_TEMPLATE = f"{BASE_URL}/api/scripts/{SCRIPT_ID}/result/{{}}"


# 通过upload_file将计算所需的输入文件上传到服务器
def upload_file(file_path):
    # API 规定的默认上传地址
    upload_endpoint = "http://114.214.215.131:40080/worker/file/upload"

    # 你的鉴权 Token
    # 文档提到 "FILE_UPLOAD_IDENTIFIES must be present in the environment"，
    # 在直接通过 HTTP 请求调用时，这通常意味着需要将其放在 Request Headers 或表单中。
    headers = {
        "FILE_UPLOAD_IDENTIFIES": "691c9f24af764bd6ac955a0e8dd0dba9"
    }

    if not os.path.exists(file_path):
        raise FileNotFoundError(f"找不到文件: {file_path}，请检查路径是否正确。")

    print(f"开始上传文件: {file_path} ...")

    with open(file_path, 'rb') as f:
        # 大多数 API 接收的上传字段名为 'file'，如果报错可以尝试改成 'inputfile' 或其他
        files = {'file': (os.path.basename(file_path), f)}

        try:
            response = requests.post(upload_endpoint, headers=headers, files=files)
            response.raise_for_status()  # 检查是否有 4xx/5xx HTTP 错误

            result_data = response.json()
            print("=> 服务器原始响应: ", result_data)

            return result_data['data'], result_data

        except requests.exceptions.RequestException as e:
            print(f"\n❌ 请求失败: {e}")
            return None


def submit_gaussian_task(file_url, objective="计算", tasks_per_node=32, n_nodes=1, auth_token=None):
    """
    提交 Gaussian 计算任务
    """
    print(f"\n🚀 开始提交计算任务...")

    # 构建 script_params.json 的内容
    script_params = {
        "objective": objective,
        "inputfile": file_url,
        "tasks_per_node": tasks_per_node,
        "n_nodes": n_nodes
    }

    # 构造请求体，注意 script_params.json 必须是一个被 JSON 序列化的字符串
    payload = {
        "arg": "gaussian_run",  # 随意传一个字符串
        "attachments": {
            "inputfile": file_url,
            "script_params.json": json.dumps(script_params)
        }
    }

    headers = {"Content-Type": "application/json"}
    if auth_token:
        headers["Authorization"] = f"Bearer {auth_token}"

    try:
        response = requests.post(EXECUTE_ENDPOINT, json=payload, headers=headers)
        response.raise_for_status()
        result_data = response.json()
        print("=> 提交响应:", result_data)

        # 文档指出：返回键名未知，提取第一个看起来像 UUID 的值作为 execution_id
        # 使用正则表达式匹配标准 UUID 格式 (8-4-4-4-12)
        uuid_pattern = r'[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}'
        # 将整个返回体转为字符串来搜索
        matches = re.findall(uuid_pattern, json.dumps(result_data))

        if matches:
            execution_id = matches[0]
            print(f"✅ 任务提交成功！提取到 execution_id: {execution_id}")
            return execution_id
        else:
            print("❌ 提交成功，但在返回值中未能找到 UUID 格式的任务 ID！")
            return None

    except requests.exceptions.RequestException as e:
        print(f"❌ 提交任务请求失败: {e}")
        return None


def poll_gaussian_result(execution_id, auth_token=None, poll_interval=10):
    """
    轮询获取计算结果
    """
    print(f"\n⏳ 开始轮询任务结果 (任务 ID: {execution_id})...")

    result_url = RESULT_ENDPOINT_TEMPLATE.format(execution_id)
    headers = {}
    if auth_token:
        headers["Authorization"] = f"Bearer {auth_token}"

    while True:
        try:
            response = requests.get(result_url, headers=headers)
            response.raise_for_status()
            result_payload = response.json()

            # 检查是否还在计算中
            # 文档指出：像 {"data":{"finished":false}} 这样的属于未完成
            data_field = result_payload.get("data", {})
            if isinstance(data_field, dict) and data_field.get("finished") is False:
                print(f"[{time.strftime('%X')}] 任务计算中，请稍候...")
                time.sleep(poll_interval)
                continue

            print(f"\n🎉 任务计算完成！")

            # 文档指出：处理 result.data.response 中的 JSON 字符串作为 result_assets
            response_str = data_field.get("response")
            if response_str and isinstance(response_str, str):
                try:
                    result_assets = json.loads(response_str)
                    result_payload["data"]["result_assets"] = result_assets
                except json.JSONDecodeError:
                    pass

            # 文档指出：把所有内网 IP (http://10.88.0.32:8396) 替换为公网 IP
            final_result_str = json.dumps(result_payload, ensure_ascii=False)
            final_result_str = final_result_str.replace("http://10.88.0.32:8396", "http://114.214.255.82:8396")

            # 转回字典返回
            final_result = json.loads(final_result_str)
            return final_result

        except requests.exceptions.RequestException as e:
            print(f"❌ 轮询结果请求失败: {e}")
            print("将在 10 秒后重试...")
            time.sleep(10)


def download_and_extract_result(result_payload, output_dir=None):
    """
    从轮询结果中提取下载链接，下载并解压计算结果，带有时间戳的安全目录名
    """
    # 如果未指定输出目录，则动态生成一个包含当前时间戳的目录名
    if output_dir is None:
        # 使用 %Y%m%d_%H%M%S 格式，避免所有的冒号和空格，保证跨平台绝对安全
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_dir = f"gaussian_results_{timestamp}"

    print(f"\n📥 开始处理下载和解压，目标文件夹: {output_dir} ...")

    # 1. 确保输出目录存在
    os.makedirs(output_dir, exist_ok=True)

    # 2. 从 payload 中安全提取 '计算结果' 的 URL
    try:
        assets = result_payload.get("data", {}).get("result_assets", {})
        result_url = assets.get("计算结果")

        if not result_url:
            print("❌ 未在返回结果中找到 '计算结果' 的下载链接！")
            return None

        print(f"🔗 找到计算结果链接: {result_url}")

    except AttributeError:
        print("❌ 解析返回数据失败，数据格式不正确。")
        return None

    # 3. 构造本地保存的压缩包路径
    zip_filename = result_url.split("/")[-1]
    zip_filepath = os.path.join(output_dir, zip_filename)

    # 4. 下载文件（带自动重试机制，专治网络闪断）
    print(f"⬇️ 开始全速下载 {zip_filename} ...")

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
        "Connection": "keep-alive"
    }

    max_retries = 3
    download_success = False

    for attempt in range(max_retries):
        try:
            # 设置一个合理的超时时间 (连接超时 10秒，读取超时 30秒)
            response = requests.get(result_url, stream=True, headers=headers, timeout=(10, 30))
            response.raise_for_status()

            # 遇到网络不稳定，切片不要太大，改回 64KB，保证细水长流不超时
            chunk_size = 65536

            with open(zip_filepath, 'wb') as f:
                for chunk in response.iter_content(chunk_size=chunk_size):
                    if chunk:
                        f.write(chunk)

            print(f"✅ 下载完成: {zip_filepath}")
            download_success = True
            break  # 下载成功，跳出重试循环

        except Exception as e:
            # 捕获所有由于网络中断引发的异常 (如 IncompleteRead, ChunkedEncodingError 等)
            print(f"⚠️ 第 {attempt + 1} 次下载尝试中断: {e}")
            if attempt < max_retries - 1:
                print("⏳ 等待 3 秒后准备重新下载...")
                import time
                time.sleep(3)
            else:
                print("❌ 达到最大重试次数，下载彻底失败。")

    if not download_success:
        return None

    # 5. 解压文件
    # 直接解压到带有时间戳的主目录中，或者你也可以保留子目录
    extract_folder_name = zip_filename.replace(".zip", "")
    extract_dir = os.path.join(output_dir, extract_folder_name)
    os.makedirs(extract_dir, exist_ok=True)

    print(f"📦 开始解压到: {extract_dir} ...")
    try:
        with zipfile.ZipFile(zip_filepath, 'r') as zip_ref:
            zip_ref.extractall(extract_dir)
        print(f"🎉 解压成功！所有文件已保存在: {extract_dir}")
        return extract_dir

    except zipfile.BadZipFile:
        print("❌ 解压失败：下载的文件不是有效的 zip 压缩包。")
        return None


if __name__ == "__main__":
    LOCAL_FILE = '/Users/zikaixie/Library/Containers/com.tencent.xinWeChat/Data/Library/Application Support/com.tencent.xinWeChat/2.0b4.0.9/eb4e397a01da9f637047f56a1597e785/Message/MessageTemp/c9a7506a7bf93d388940bb4aa449e378/File/scripts_step3 2/benzene_calc/benzene.gjf'
    r = upload_file(LOCAL_FILE)
    uploaded_file_url = r[1]['data']
    # 1. 提交任务 (参数按照你的需求修改，注意必须从文档给定的枚举里选)
    task_id = submit_gaussian_task(
        file_url=uploaded_file_url
    )

    # 2. 如果提交成功，开始轮询结果
    if task_id:
        # poll_interval 控制每次轮询的间隔秒数，超算可能比较慢，可以设置得大一点比如 15 秒或 30 秒
        final_data = poll_gaussian_result(task_id, poll_interval=15)

        print("\n=== 最终计算结果 ===")
        # 直接打印处理后的 payload（保留原始结构，方便你后续提取产物文件链接）
        print(json.dumps(final_data, indent=2, ensure_ascii=False))

        download_and_extract_result(final_data)