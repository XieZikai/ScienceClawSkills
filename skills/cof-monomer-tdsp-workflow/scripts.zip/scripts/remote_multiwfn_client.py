import json
import re
import shutil
import time
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Dict, Optional, Tuple

import requests


class RemoteMultiwfnClient:
    """Upload .fchk files, run a remote Multiwfn/dohe script, then download .he.txt results."""

    def __init__(self, config: Dict):
        self.enabled = bool(config.get("enabled", False))
        self.upload_endpoint = str(config.get("upload_endpoint", "")).rstrip("/")
        self.file_upload_token = config.get("file_upload_token")
        self.file_upload_header = config.get("file_upload_header", "FILE_UPLOAD_IDENTIFIES")
        self.script_base_url = str(config.get("script_base_url", "")).rstrip("/")
        self.script_id = config.get("script_id")
        self.execute_endpoint = config.get(
            "execute_endpoint",
            f"{self.script_base_url}/api/scripts/{self.script_id}/execute" if self.script_base_url and self.script_id else None,
        )
        self.result_endpoint_template = config.get(
            "result_endpoint_template",
            f"{self.script_base_url}/api/scripts/{self.script_id}/result/{{execution_id}}" if self.script_base_url and self.script_id else None,
        )
        self.script_auth_token = config.get("script_auth_token")
        self.poll_interval = int(config.get("poll_interval_seconds", 15))
        self.max_poll_attempts = int(config.get("max_poll_attempts", 720))
        self.arg = config.get("arg", "multiwfn_he")
        self.objective = config.get("objective", "Multiwfn hole-electron analysis")
        self.download_headers = config.get("download_headers", {
            "User-Agent": "Mozilla/5.0",
            "Connection": "keep-alive",
        })
        self.remote_output_name = config.get("remote_output_name")
        self.result_asset_key = config.get("result_asset_key")
        self.public_base_url = str(config.get("public_base_url", self.script_base_url)).rstrip("/") if (config.get("public_base_url") or self.script_base_url) else ""
        self.internal_base_url = config.get("internal_base_url", "http://10.88.0.32:8396")

    def validate_enabled(self) -> None:
        if not self.enabled:
            raise RuntimeError("Remote Multiwfn execution is not enabled in the skill config.")
        required = {
            "upload_endpoint": self.upload_endpoint,
            "file_upload_token": self.file_upload_token,
            "script_base_url": self.script_base_url,
            "script_id": self.script_id,
            "execute_endpoint": self.execute_endpoint,
            "result_endpoint_template": self.result_endpoint_template,
        }
        missing = [k for k, v in required.items() if not v]
        if missing:
            raise RuntimeError(
                "Remote Multiwfn is enabled but missing config fields: " + ", ".join(missing)
            )

    def run_he(self, fchk_path: Path, output_path: Optional[Path] = None) -> Path:
        self.validate_enabled()
        fchk_path = Path(fchk_path)
        if not fchk_path.exists():
            raise FileNotFoundError(f"FCHK file not found: {fchk_path}")

        remote_file_url, _ = self._upload_file(fchk_path)
        execution_id = self._submit_task(remote_file_url, fchk_path.name)
        result_payload = self.wait_for_completion(execution_id)
        return self.download_results(result_payload, fchk_path.parent, fchk_path.stem, output_path=output_path)

    def _upload_file(self, file_path: Path) -> Tuple[str, Dict]:
        headers = {self.file_upload_header: self.file_upload_token}
        print(f"[REMOTE-MULTIWFN][UPLOAD] Uploading {file_path} ...")
        with open(file_path, "rb") as handle:
            files = {"file": (file_path.name, handle)}
            response = requests.post(self.upload_endpoint, headers=headers, files=files)
        response.raise_for_status()
        data = response.json()
        url = data.get("data")
        if not url:
            raise RuntimeError("Remote Multiwfn upload response missing 'data' field.")
        print(f"[REMOTE-MULTIWFN][UPLOAD] Success. Remote URL: {url}")
        return url, data

    def _submit_task(self, file_url: str, original_name: str) -> str:
        payload = {
            "arg": self.arg,
            "attachments": {
                "inputfile": file_url,
                "script_params.json": json.dumps({
                    "objective": self.objective,
                    "inputfile": file_url,
                    "input_name": original_name,
                    **({"output_name": self.remote_output_name} if self.remote_output_name else {}),
                })
            }
        }
        headers = {"Content-Type": "application/json"}
        if self.script_auth_token:
            headers["Authorization"] = f"Bearer {self.script_auth_token}"

        print(f"[REMOTE-MULTIWFN][SUBMIT] Submitting remote HE task for {original_name} ...")
        response = requests.post(self.execute_endpoint, json=payload, headers=headers)
        response.raise_for_status()
        reply = response.json()
        execution_id = self._extract_uuid(reply)
        if not execution_id:
            raise RuntimeError(f"Remote Multiwfn submission did not return an execution_id-like UUID: {reply}")
        print(f"[REMOTE-MULTIWFN][SUBMIT] Submission accepted. Execution ID: {execution_id}")
        return execution_id

    def wait_for_completion(self, execution_id: str) -> Dict:
        attempts = 0
        while attempts < self.max_poll_attempts:
            payload = self._poll_result(execution_id)
            data = payload.get("data", {})
            if isinstance(data, dict) and data.get("finished") is False:
                print(f"[REMOTE-MULTIWFN][POLL] Task {execution_id} running... ({attempts + 1}/{self.max_poll_attempts})")
                attempts += 1
                time.sleep(self.poll_interval)
                continue
            print(f"[REMOTE-MULTIWFN][POLL] Task {execution_id} finished.")
            return payload
        raise TimeoutError(
            f"Remote Multiwfn task {execution_id} did not finish within {self.max_poll_attempts * self.poll_interval / 60:.1f} minutes"
        )

    def _poll_result(self, execution_id: str) -> Dict:
        headers = {}
        if self.script_auth_token:
            headers["Authorization"] = f"Bearer {self.script_auth_token}"
        response = requests.get(self.result_endpoint_template.format(execution_id=execution_id), headers=headers)
        response.raise_for_status()
        payload = response.json()
        data_field = payload.get("data", {})
        if isinstance(data_field, dict):
            response_str = data_field.get("response")
            if response_str and isinstance(response_str, str):
                try:
                    payload["data"]["result_assets"] = json.loads(response_str)
                except json.JSONDecodeError:
                    pass
        if self.internal_base_url and self.public_base_url:
            payload_str = json.dumps(payload, ensure_ascii=False)
            if self.internal_base_url in payload_str:
                payload = json.loads(payload_str.replace(self.internal_base_url, self.public_base_url))
        return payload

    def download_results(self, result_payload: Dict, target_dir: Path, job_name: str, output_path: Optional[Path] = None) -> Path:
        result_url = self._extract_result_url(result_payload)
        if not result_url:
            raise RuntimeError(f"Remote Multiwfn result payload does not contain a download URL: {result_payload}")

        target_dir = Path(target_dir)
        target_dir.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        job_output_root = target_dir / f"{job_name}_remote_he_{timestamp}"
        job_output_root.mkdir(parents=True, exist_ok=True)

        zip_filename = result_url.split("/")[-1]
        zip_path = job_output_root / zip_filename
        self._download_file(result_url, zip_path)

        extract_dir = job_output_root / zip_filename.replace(".zip", "")
        extract_dir.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(zip_path, "r") as zip_ref:
            zip_ref.extractall(extract_dir)

        he_src = self._find_artifact(extract_dir, job_name, suffix=".he.txt")
        if not he_src:
            raise FileNotFoundError(
                f"Unable to locate .he.txt in extracted remote Multiwfn results for {job_name}. Contents: " +
                " | ".join(str(p) for p in extract_dir.rglob("*"))
            )

        he_dst = output_path or (target_dir / f"{job_name}.he.txt")
        shutil.copy2(he_src, he_dst)
        print(f"[REMOTE-MULTIWFN][DOWNLOAD] Saved HE report to {he_dst}")
        return he_dst

    def _download_file(self, url: str, dest: Path) -> None:
        print(f"[REMOTE-MULTIWFN][DOWNLOAD] Fetching {url} ...")
        with requests.get(url, stream=True, headers=self.download_headers, timeout=(10, 30)) as r:
            r.raise_for_status()
            with open(dest, "wb") as f:
                for chunk in r.iter_content(chunk_size=65536):
                    if chunk:
                        f.write(chunk)
        print(f"[REMOTE-MULTIWFN][DOWNLOAD] Saved zip to {dest}")

    def _extract_result_url(self, payload: Dict) -> Optional[str]:
        data = payload.get("data", {})
        if not isinstance(data, dict):
            return None
        assets = data.get("result_assets", {})
        if isinstance(assets, dict):
            if self.result_asset_key and assets.get(self.result_asset_key):
                return assets.get(self.result_asset_key)
            if assets.get("计算结果"):
                return assets.get("计算结果")
            return next(iter(assets.values()), None)
        return None

    @staticmethod
    def _extract_uuid(payload: Dict) -> Optional[str]:
        uuid_pattern = r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}"
        matches = re.findall(uuid_pattern, json.dumps(payload, ensure_ascii=False))
        return matches[0] if matches else None

    @staticmethod
    def _find_artifact(extract_dir: Path, job_name: str, suffix: str) -> Optional[Path]:
        preferred = list(extract_dir.rglob(f"{job_name}{suffix}"))
        if preferred:
            return preferred[0]
        generic = list(extract_dir.rglob(f"*{suffix}"))
        return generic[0] if generic else None
