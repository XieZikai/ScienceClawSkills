import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Dict, Optional

import requests


class SupercomputerClient:
    """HTTP client that mirrors the new Gaussian upload/submit/poll workflow."""

    def __init__(self, config_path: str):
        self.config_path = Path(config_path)
        if not self.config_path.exists():
            raise FileNotFoundError(f"Supercomputer config not found: {config_path}")

        with open(self.config_path, "r", encoding="utf-8") as f:
            cfg = json.load(f)

        self.upload_endpoint = cfg["upload_endpoint"].rstrip("/")
        self.file_upload_token = cfg["file_upload_token"]
        self.script_base_url = cfg["script_base_url"].rstrip("/")
        self.script_id = cfg["script_id"]
        self.execute_endpoint = cfg.get(
            "execute_endpoint",
            f"{self.script_base_url}/api/scripts/{self.script_id}/execute"
        )
        self.result_endpoint_template = cfg.get(
            "result_endpoint_template",
            f"{self.script_base_url}/api/scripts/{self.script_id}/result/{{execution_id}}"
        )
        self.script_auth_token = cfg.get("script_auth_token")
        self.poll_interval = cfg.get("poll_interval_seconds", 15)
        self.max_poll_attempts = cfg.get("max_poll_attempts", 2880)
        self.tasks_per_node = cfg.get("tasks_per_node", 32)
        self.n_nodes = cfg.get("n_nodes", 1)
        self.default_objective = cfg.get("objective", "计算")
        self.objective_map = cfg.get("objective_map", {})
        self.download_headers = cfg.get("download_headers", {
            "User-Agent": "Mozilla/5.0",
            "Connection": "keep-alive"
        })

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def submit_gaussian_job(self, gjf_path: Path, job_type: Optional[str] = None) -> str:
        """Upload a Gaussian input file and submit it to the remote script."""
        gjf_path = Path(gjf_path)
        if not gjf_path.exists():
            raise FileNotFoundError(f"GJF file not found: {gjf_path}")

        file_url, _ = self._upload_file(gjf_path)
        objective = self.objective_map.get(job_type, self.default_objective)
        execution_id = self._submit_task(file_url, objective)
        if not execution_id:
            raise RuntimeError("Failed to obtain execution ID from submission response.")
        return execution_id

    def wait_for_completion(self, execution_id: str) -> Dict:
        """Poll the script result endpoint until the task finishes."""
        attempts = 0
        while attempts < self.max_poll_attempts:
            payload = self._poll_result(execution_id)
            data = payload.get("data", {})
            if isinstance(data, dict) and data.get("finished") is False:
                print(f"[HPC] Task {execution_id} running... ({attempts + 1}/{self.max_poll_attempts})")
                attempts += 1
                time.sleep(self.poll_interval)
                continue

            print(f"[HPC] Task {execution_id} finished.")
            return payload

        raise TimeoutError(
            f"Task {execution_id} did not finish within {self.max_poll_attempts * self.poll_interval / 60:.1f} minutes"
        )

    def download_results(self, result_payload: Dict, target_dir: Path, job_name: str) -> Dict[str, Path]:
        """Download the zip artifact, extract it, and return copied log/fchk paths.

        Accept result bundles that only contain .chk + Gaussian log; generate .fchk locally
        via formchk so downstream descriptor steps can continue.
        """
        result_url = self._extract_result_url(result_payload)
        if not result_url:
            raise RuntimeError("Result payload does not contain a download URL.")

        target_dir = Path(target_dir)
        target_dir.mkdir(parents=True, exist_ok=True)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        job_output_root = target_dir / f"{job_name}_remote_{timestamp}"
        job_output_root.mkdir(parents=True, exist_ok=True)

        zip_filename = result_url.split("/")[-1]
        zip_path = job_output_root / zip_filename
        self._download_file(result_url, zip_path)

        extract_dir = job_output_root / zip_filename.replace(".zip", "")
        extract_dir.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(zip_path, "r") as zip_ref:
            zip_ref.extractall(extract_dir)

        log_src = self._find_log_artifact(extract_dir, job_name)
        fchk_src = self._find_artifact(extract_dir, job_name, suffix=".fchk")
        chk_src = self._find_artifact(extract_dir, job_name, suffix=".chk")

        if not fchk_src and chk_src:
            generated_fchk = extract_dir / f"{job_name}.fchk"
            fchk_src = self._generate_fchk_from_chk(chk_src, generated_fchk)

        if not log_src or not fchk_src:
            search_hint = " | ".join(str(p) for p in extract_dir.rglob("*"))
            raise FileNotFoundError(
                f"Unable to locate usable .log/.fchk in extracted results for {job_name}. Contents: {search_hint}"
            )

        log_dst = target_dir / f"{job_name}.log"
        fchk_dst = target_dir / f"{job_name}.fchk"
        shutil.copy2(log_src, log_dst)
        shutil.copy2(fchk_src, fchk_dst)

        return {
            "log": log_dst,
            "fchk": fchk_dst,
            "extract_dir": extract_dir,
            "zip_path": zip_path
        }

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------
    def _upload_file(self, file_path: Path) -> (str, Dict):
        headers = {"FILE_UPLOAD_IDENTIFIES": self.file_upload_token}
        print(f"[UPLOAD] Uploading {file_path} ...")
        with open(file_path, "rb") as handle:
            files = {"file": (file_path.name, handle)}
            response = requests.post(self.upload_endpoint, headers=headers, files=files)
        response.raise_for_status()
        data = response.json()
        url = data.get("data")
        if not url:
            raise RuntimeError("Upload response missing 'data' field.")
        print(f"[UPLOAD] Success. Remote URL: {url}")
        return url, data

    def _submit_task(self, file_url: str, objective: str) -> Optional[str]:
        payload = {
            "arg": "gaussian_run",
            "attachments": {
                "inputfile": file_url,
                "script_params.json": json.dumps({
                    "objective": objective,
                    "inputfile": file_url,
                    "tasks_per_node": self.tasks_per_node,
                    "n_nodes": self.n_nodes
                })
            }
        }

        headers = {"Content-Type": "application/json"}
        if self.script_auth_token:
            headers["Authorization"] = f"Bearer {self.script_auth_token}"

        print(f"[SUBMIT] Submitting Gaussian task ({objective}) ...")
        response = requests.post(self.execute_endpoint, json=payload, headers=headers)
        response.raise_for_status()
        payload = response.json()
        execution_id = self._extract_uuid(payload)
        print(f"[SUBMIT] Submission accepted. Execution ID: {execution_id}")
        return execution_id

    def _poll_result(self, execution_id: str) -> Dict:
        result_url = self.result_endpoint_template.format(execution_id=execution_id)
        headers = {}
        if self.script_auth_token:
            headers["Authorization"] = f"Bearer {self.script_auth_token}"
        response = requests.get(result_url, headers=headers)
        response.raise_for_status()
        payload = response.json()

        data_field = payload.get("data", {})
        if isinstance(data_field, dict):
            response_str = data_field.get("response")
            if response_str and isinstance(response_str, str):
                try:
                    result_assets = json.loads(response_str)
                    payload["data"]["result_assets"] = result_assets
                except json.JSONDecodeError:
                    pass

            replace_target = "http://10.88.0.32:8396"
            payload_str = json.dumps(payload, ensure_ascii=False)
            if replace_target in payload_str:
                payload_str = payload_str.replace(replace_target, self.script_base_url)
                payload = json.loads(payload_str)

        return payload

    def _download_file(self, url: str, dest: Path):
        print(f"[DOWNLOAD] Fetching {url} ...")
        max_retries = 3
        for attempt in range(max_retries):
            try:
                with requests.get(url, stream=True, headers=self.download_headers, timeout=(10, 30)) as r:
                    r.raise_for_status()
                    with open(dest, "wb") as f:
                        for chunk in r.iter_content(chunk_size=65536):
                            if chunk:
                                f.write(chunk)
                print(f"[DOWNLOAD] Saved to {dest}")
                return
            except Exception as exc:
                print(f"[DOWNLOAD] Attempt {attempt + 1} failed: {exc}")
                if attempt == max_retries - 1:
                    raise
                time.sleep(3)

    @staticmethod
    def _extract_uuid(payload: Dict) -> Optional[str]:
        uuid_pattern = r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}"
        matches = re.findall(uuid_pattern, json.dumps(payload))
        return matches[0] if matches else None

    @staticmethod
    def _extract_result_url(payload: Dict) -> Optional[str]:
        data = payload.get("data", {})
        if not isinstance(data, dict):
            return None
        assets = data.get("result_assets", {})
        if isinstance(assets, dict):
            return assets.get("计算结果") or next(iter(assets.values()), None)
        return None

    @staticmethod
    def _find_artifact(extract_dir: Path, job_name: str, suffix: str) -> Optional[Path]:
        preferred = list(extract_dir.rglob(f"{job_name}{suffix}"))
        if preferred:
            return preferred[0]
        generic = list(extract_dir.rglob(f"*{suffix}"))
        return generic[0] if generic else None

    @staticmethod
    def _find_log_artifact(extract_dir: Path, job_name: str) -> Optional[Path]:
        preferred_names = [
            f"{job_name}.log",
            f"job_gaussian_{job_name}.log",
            "input.log",
        ]
        for name in preferred_names:
            matches = list(extract_dir.rglob(name))
            if matches:
                return matches[0]

        gaussian_logs = sorted(extract_dir.rglob("job_gaussian*.log"))
        if gaussian_logs:
            return gaussian_logs[0]

        return SupercomputerClient._find_artifact(extract_dir, job_name, suffix=".log")

    @staticmethod
    def _generate_fchk_from_chk(chk_path: Path, output_fchk: Path) -> Optional[Path]:
        try:
            result = subprocess.run(
                ["formchk", str(chk_path), str(output_fchk)],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=180,
                check=False,
            )
            if result.returncode == 0 and output_fchk.exists():
                return output_fchk
            sys.stderr.write(
                f"[WARN] formchk failed for {chk_path}: rc={result.returncode}\n{result.stderr}\n"
            )
        except Exception as exc:
            sys.stderr.write(f"[WARN] formchk exception for {chk_path}: {exc}\n")
        return None
