import argparse
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Dict, Optional

from rdkit import Chem
from rdkit.Chem import AllChem

from hpc_client import SupercomputerClient

# 尝试导入你的自定义库用于最终的描述符提取
try:
    from djh.formchk_interface import FormchkInterface
    from djh.my_libs import logfile, Mwfn
    from djh.cdft import read_CDFT, runcdft
    from djh.read_he import read_hole_contri
except ImportError:
    print(
        "Warning: Custom 'djh' modules not found. Descriptor extraction step may fail if not run in the correct environment.")


# ---------------------------------------------------------------------------
# Structure preparation helpers
# ---------------------------------------------------------------------------
def smiles_to_xyz(smiles: str, output_path: Path) -> str:
    """Generate an XYZ file from a SMILES string."""
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        raise ValueError(f"Failed to parse SMILES: {smiles}")

    mol = Chem.AddHs(mol)

    strategies = []

    p1 = AllChem.ETKDGv3()
    p1.randomSeed = 42
    strategies.append(("ETKDGv3(seed=42)", p1))

    p2 = AllChem.ETKDGv3()
    p2.randomSeed = 7
    p2.useRandomCoords = True
    strategies.append(("ETKDGv3(seed=7,randomCoords)", p2))

    p3 = AllChem.ETKDGv3()
    p3.randomSeed = 2026
    p3.useRandomCoords = True
    strategies.append(("ETKDGv3(seed=2026,randomCoords)", p3))

    p4 = AllChem.ETKDGv2()
    p4.randomSeed = 99
    p4.useRandomCoords = True
    strategies.append(("ETKDGv2(seed=99,randomCoords)", p4))

    last_status = None
    last_error = None
    success = False

    for label, params in strategies:
        work_mol = Chem.Mol(mol)
        try:
            status = AllChem.EmbedMolecule(work_mol, params)
            print(f"[INFO] Embed attempt {label}: status={status}")
            if status == 0:
                try:
                    AllChem.UFFOptimizeMolecule(work_mol, maxIters=500)
                except Exception as opt_exc:
                    print(f"[WARN] UFF optimize failed after {label}: {opt_exc}")
                mol = work_mol
                last_status = status
                success = True
                break
            last_status = status
        except Exception as exc:
            last_error = exc
            print(f"[WARN] Embed attempt {label} raised: {exc}")

    if not success:
        try:
            work_mol = Chem.Mol(mol)
            status = AllChem.EmbedMolecule(work_mol, randomSeed=1234, useRandomCoords=True)
            print(f"[INFO] Embed attempt distance-geometry fallback: status={status}")
            if status == 0:
                try:
                    AllChem.UFFOptimizeMolecule(work_mol, maxIters=500)
                except Exception as opt_exc:
                    print(f"[WARN] UFF optimize failed after distance-geometry fallback: {opt_exc}")
                mol = work_mol
                last_status = status
                success = True
            else:
                last_status = status
        except Exception as exc:
            last_error = exc
            print(f"[WARN] Distance-geometry fallback raised: {exc}")

    if not success:
        msg = f"3D embedding failed after multiple strategies (last status {last_status}). Check SMILES: {smiles}"
        if last_error is not None:
            msg += f" | last exception: {last_error}"
        raise RuntimeError(msg)

    conf = mol.GetConformer()
    num_atoms = mol.GetNumAtoms()

    lines = [str(num_atoms), f"Generated from SMILES: {smiles}"]
    for i in range(num_atoms):
        atom = mol.GetAtomWithIdx(i)
        pos = conf.GetAtomPosition(i)
        symbol = atom.GetSymbol()
        lines.append(f"{symbol:2s}  {pos.x:12.6f}  {pos.y:12.6f}  {pos.z:12.6f}")

    xyz_text = "\n".join(lines) + "\n"
    output_path.write_text(xyz_text)
    print(f"[INFO] 初始XYZ结构已生成: {output_path} ({num_atoms} atoms)")
    return xyz_text


def generate_gjf(xyz_path: Path, job_type: str, nproc='32', mem='32gb') -> Path:
    """Generate Gaussian .gjf input file from .xyz file."""
    chrg = '0'
    spin = '1'

    if job_type == 'opt':
        key1 = '#p opt freq wb97xd nosymm 6-311+g** cphf=grid=fine'
    elif job_type == 'plus':
        key1 = '#p stable=opt wb97xd nosymm 6-311+g** scf=xqc'
        chrg = '-1'
        spin = '2'
    elif job_type == 'minus':
        key1 = '#p stable=opt wb97xd nosymm 6-311+g** scf=xqc'
        chrg = '1'
        spin = '2'
    elif job_type == 'tdsp':
        key1 = '#p pbe1pbe/def2tzvp iop(9/40=4) td(nstates=5,root=1) nosymm'
        chrg = '0'
        spin = '1'
    else:
        raise ValueError(f"Unknown job type: {job_type}")

    xyz_lines = xyz_path.read_text().splitlines()
    gjf_path = xyz_path.with_suffix('.gjf')
    chk_name = xyz_path.stem + '.chk'

    with open(gjf_path, 'w') as f:
        f.write(f'%nproc={nproc}\n')
        f.write(f'%mem={mem}\n')
        f.write(f'%chk={chk_name}\n')
        f.write(f'{key1}\n\n')
        f.write(f'Title: {job_type} calculation\n\n')
        f.write(f'{chrg} {spin}\n')
        for line in xyz_lines[2:]:
            f.write(line + '\n')
        f.write('\n\n')

    print(f"[INFO] GJF文件已生成: {gjf_path} (Job: {job_type})")
    return gjf_path


# ---------------------------------------------------------------------------
# Remote Gaussian execution helpers
# ---------------------------------------------------------------------------
def run_remote_gaussian(gjf_path: Path, client: SupercomputerClient, job_type: str,
                        is_tdsp: bool = False,
                        dohe_env_var: str = "DOHE_SCRIPT_PATH") -> Path:
    """Submit Gaussian job via the script workflow and return the .log path."""
    workdir = gjf_path.parent
    job_name = gjf_path.stem

    print(f"[HPC] Submitting job {job_name} ({job_type}) from {workdir} ...")
    execution_id = client.submit_gaussian_job(gjf_path, job_type=job_type)
    result_payload = client.wait_for_completion(execution_id)
    artifacts = client.download_results(result_payload, workdir, job_name)

    log_path = artifacts["log"]
    fchk_path = artifacts["fchk"]

    if is_tdsp:
        run_dohe_analysis(fchk_path, dohe_env_var)

    print(f"[HPC] Job {job_name} completed successfully.")
    return log_path


def run_dohe_analysis(fchk_path: Path, env_var: str = "DOHE_SCRIPT_PATH"):
    """Run hole-electron analysis via the dedicated multiwfn skill helper instead of legacy dohe.py piping."""
    skill_root = Path(__file__).resolve().parents[2] / 'multiwfn-mac'
    helper_script = skill_root / 'scripts' / 'calc_he_s1.py'
    multiwfn_bin = skill_root / 'multiwfn' / 'multiwfn'
    output_path = fchk_path.with_suffix('.he.txt')

    if not helper_script.exists():
        raise FileNotFoundError(
            f"Multiwfn helper skill not found: {helper_script}")

    cmd = [sys.executable, str(helper_script), str(fchk_path), '--output', str(output_path)]
    if multiwfn_bin.exists():
        cmd.extend(['--multiwfn', str(multiwfn_bin)])

    print(f"[RUNNING] Executing hole-electron analysis via multiwfn skill helper {helper_script} ...")
    subprocess.run(cmd, cwd=fchk_path.parent, check=True)


# ---------------------------------------------------------------------------
# Post-processing helpers
# ---------------------------------------------------------------------------
def log_to_xyz_multiwfn(log_path: Path) -> Path:
    """Use the dedicated multiwfn skill helper to convert a Gaussian .log file to .xyz structure."""
    xyz_path = log_path.with_suffix('.xyz')
    skill_root = Path(__file__).resolve().parents[2] / 'multiwfn-mac'
    helper_script = skill_root / 'scripts' / 'log_to_xyz.py'
    multiwfn_bin = skill_root / 'multiwfn' / 'multiwfn'

    if not helper_script.exists():
        raise FileNotFoundError(f"Multiwfn log→xyz helper skill not found: {helper_script}")

    cmd = [sys.executable, str(helper_script), str(log_path), '--output', str(xyz_path)]
    if multiwfn_bin.exists():
        cmd.extend(['--multiwfn', str(multiwfn_bin)])

    print(f"[INFO] 正在通过 multiwfn skill 将 {log_path} 转换为 {xyz_path} ...")
    subprocess.run(cmd, check=True)
    return xyz_path


def extract_descriptors(workdir: Path, base_name: str, des_output: str):
    """Run the descriptor extraction logic and save to .des file."""
    print(f"[INFO] 开始提取描述符...")
    cwd = Path.cwd()
    os.chdir(workdir)

    fchknam = f"{base_name}.fchk"

    shutil.copy(f"minus/{fchknam}", f"./{base_name}-1.fchk")
    shutil.copy(f"plus/{fchknam}", f"./{base_name}+1.fchk")

    original_stdout = os.sys.stdout
    with open(des_output, 'w') as f_out:
        os.sys.stdout = f_out  # 重定向 print 输出到 .des 文件

        try:
            fchk = FormchkInterface(fchknam)
            print('HOMO: ', fchk.homo()[0])
            print('LUMO: ', fchk.lumo()[0])
            print('GAP: ', fchk.gap()[0])

            runcdft(fchknam)
            hirsh_char_0, hirsh_char_p, hirsh_char_m, cfuk_plus, cfuk_minus, cfuk_0, \
                cdd, cele_ph, cnuc_ph, c_soft_plus, c_soft_minus, c_soft_0, \
                vip, vea, mull_ele_neg, hardness, softness = read_CDFT(fchknam)

            print('VIP: ', vip)
            print('VEA: ', vea)

            tdlog = f"tdsp/{base_name}.log"
            s1line_cmd = f"grep -rn ' f=' {tdlog} | tail -n 1"
            s1line = subprocess.getoutput(s1line_cmd)

            ex_energy = s1line.split()[-6]
            fosc = float(s1line.split()[-2].split('=')[-1])
            print('ex_energy: ', ex_energy)
            print('fosc: ', fosc)

            tdfchk = f"tdsp/{fchknam}"
            sr, d_index, hdi, edi, hole_contri, elec_contri = read_hole_contri(tdfchk)
            print('sr: ', sr)
            print('d_index: ', d_index)
            print('hdi: ', hdi)
            print('edi: ', edi)

        except Exception as e:
            os.sys.stdout = original_stdout
            os.chdir(cwd)
            raise RuntimeError(f"[ERROR] 提取描述符时发生错误: {e}")

    os.sys.stdout = original_stdout
    os.chdir(cwd)
    print(f"[INFO] 描述符提取完成，已保存至: {workdir / des_output}")


# ---------------------------------------------------------------------------
# Main workflow
# ---------------------------------------------------------------------------
def load_resources_override(json_str: Optional[str]) -> Optional[Dict]:
    if not json_str:
        return None
    return json.loads(json_str)


def main():
    parser = argparse.ArgumentParser(description="Automated SMILES to Chemical Descriptors Workflow")
    parser.add_argument("--smiles", type=str, required=True, help="Input SMILES string")
    parser.add_argument("--name", type=str, default="molecule", help="Base name for the generated files")
    parser.add_argument("--workdir", type=str, default="calc_workspace",
                        help="Directory to store all intermediate files")
    parser.add_argument("--nproc", type=str, default="32", help="Number of processors for Gaussian")
    parser.add_argument("--mem", type=str, default="32gb", help="Memory for Gaussian")
    parser.add_argument("--config", type=str, default="config/supercomputer_config.json",
                        help="Path to the supercomputer API configuration file")
    parser.add_argument("--resources", type=str, default=None,
                        help="Optional JSON string overriding resource request (e.g. '{\"cpus\":64}')")
    parser.add_argument("--dohe-env", type=str, default="DOHE_SCRIPT_PATH",
                        help="Environment variable that points to the dohe.py executable")
    args = parser.parse_args()

    workdir = Path(args.workdir).resolve()
    workdir.mkdir(parents=True, exist_ok=True)
    print(f"=== 开始执行计算流 | 工作目录: {workdir} ===")

    client = SupercomputerClient(args.config)
    resource_override = load_resources_override(args.resources)
    if resource_override:
        print("[WARN] Resource overrides are ignored by the script-based submission workflow.")

    # 1. SMILES -> XYZ
    init_xyz = workdir / f"{args.name}.xyz"
    smiles_to_xyz(args.smiles, init_xyz)

    # 2. Geometry optimization
    opt_gjf = generate_gjf(init_xyz, job_type='opt', nproc=args.nproc, mem=args.mem)
    opt_log = run_remote_gaussian(opt_gjf, client, job_type='opt', is_tdsp=False, dohe_env_var=args.dohe_env)

    # 3. Convert optimized log to xyz
    opt_xyz = log_to_xyz_multiwfn(opt_log)

    # 4. Submit plus / minus / tdsp states
    tasks = ['plus', 'minus', 'tdsp']
    for state in tasks:
        state_dir = workdir / state
        state_dir.mkdir(parents=True, exist_ok=True)

        state_xyz = state_dir / f"{args.name}.xyz"
        shutil.copy(opt_xyz, state_xyz)

        gjf_path = generate_gjf(state_xyz, job_type=state, nproc=args.nproc, mem=args.mem)
        run_remote_gaussian(gjf_path, client, job_type=state, is_tdsp=(state == 'tdsp'),
                            dohe_env_var=args.dohe_env)

    # 5. Descriptor extraction
    des_filename = f"{args.name}.des"
    extract_descriptors(workdir, args.name, des_filename)

    print(f"=== 工作流执行完毕 ===")
    print(f"数据保存目录: {workdir}")
    print(f"最终描述符文件: {workdir / des_filename}")

    return workdir, workdir / des_filename


if __name__ == "__main__":
    main()
